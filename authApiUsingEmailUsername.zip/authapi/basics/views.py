import email
from django.shortcuts import render
#from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from basics.models import Student
from basics.serializers import StudentSerializer
from rest_framework.decorators import api_view

from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated 

#@csrf_exempt
@api_view(['GET','POST','PUT','DELETE'])
def StudentApi(request,id=None):
    permission_classes=(IsAuthenticated)
    if request.method=='GET':
        if id is not None:
            students=Student.objects.get(id=id)
            student_serializer=StudentSerializer(students)
            return Response(student_serializer.data)
        else:
            students=Student.objects.all()
            student_serializer=StudentSerializer(students,many=True)
            return Response(student_serializer.data)  
    elif request.method=='POST':
        student_data=JSONParser().parse(request)
        student_serializer=StudentSerializer(data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            return Response("Added sucessfully")
        return Response("Failed to add")
    elif request.method=='PUT':
        student_data=JSONParser().parse(request)
        student=Student.objects.get(id=student_data['id'])
        student_serializer=StudentSerializer(student,data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            return Response("Updated Sucessfully")
        return Response("Failed to update")
    elif request.method=='DELETE':
        student=Student.objects.get(id=id)
        student.delete()
        return Response("Deleted sucessfully")   


from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response

class CustomAuthToken(ObtainAuthToken):

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'email': user.email
        })

