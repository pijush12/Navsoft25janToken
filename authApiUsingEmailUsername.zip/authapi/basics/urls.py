from django.conf.urls import url 
from basics import views
from django.conf.urls.static import static
from django.conf import settings
from basics.views import CustomAuthToken,StudentApi

urlpatterns = [
    url(r'^student/$', views.StudentApi),
    url(r'^student/([0-9]+)$',views.StudentApi),
    url("api-auth-token/",CustomAuthToken.as_view()),

]